.. highlight:: shell

============
Installation
============

At the command line::

    $ easy_install civiltools

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv civiltools
    $ pip install civiltools
