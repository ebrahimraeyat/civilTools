===============================
civilTools
===============================

.. image:: https://img.shields.io/pypi/v/civiltools.svg
        :target: https://pypi.python.org/pypi/civiltools

.. image:: https://img.shields.io/travis/ebrahimraeyat/civiltools.svg
        :target: https://travis-ci.org/ebrahimraeyat/civiltools

.. image:: https://readthedocs.org/projects/civiltools/badge/?version=latest
        :target: https://readthedocs.org/projects/civiltools/?badge=latest
        :alt: Documentation Status


A series of tools for civil engineers.

* Free software: ISC license
* Documentation: https://civiltools.readthedocs.org.

Features
--------

* TODO

Credits
---------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
