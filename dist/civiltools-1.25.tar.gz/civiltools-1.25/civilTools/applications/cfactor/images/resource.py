import os
import sys

imgDir = "/home/ebi/python/cfactor/2800_class/images/"

images = "1"