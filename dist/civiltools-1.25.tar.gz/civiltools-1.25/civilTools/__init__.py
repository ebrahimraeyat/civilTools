# -*- coding: utf-8 -*-

__author__ = 'Raeyat Ebrahim'
__email__ = 'ebe79442114@yahoo.com'
__version__ = '0.1.0'
