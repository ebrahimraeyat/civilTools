=====
Usage
=====

To use civilTools in a project::

    import civiltools
